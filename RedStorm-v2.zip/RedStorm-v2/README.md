# RedStorm v2

RedStorm v2 is an educational, dependency-free Redis-style server written in Java. It accepts RESP2 requests over TCP and keeps one logical database in memory, with binary snapshots for saving and loading data. It is a Redis subset, not the upstream Redis server.

## Included files

- `RedisServer.java` — Java source code. Keep this filename because it contains the public `RedisServer` class.
- `README.md` — project overview and run instructions.

## Requirements

Java 17 or newer.

## Compile and run

From this folder:

```powershell
javac RedisServer.java
java RedisServer
```

By default, the server listens on `127.0.0.1:6379` and stores its snapshot in `redis-data.rdb` in the current directory. You can choose the port, bind address, and snapshot file:

```powershell
java RedisServer 6380 127.0.0.1 C:\data\redis-data.rdb
```

If `redis-cli` is installed, connect and try:

```text
redis-cli -h 127.0.0.1 -p 6379
127.0.0.1:6379> SET greeting hello
OK
127.0.0.1:6379> GET greeting
"hello"
```

## Included command groups

- Server and keys: `PING`, `ECHO`, `QUIT`, `TYPE`, `DEL`, `UNLINK`, `EXISTS`, `RENAME`, `RENAMENX`, `KEYS`, `SCAN` (cursor `0` only), `DBSIZE`, `FLUSHDB`, `FLUSHALL`, `SELECT 0`, `INFO`, `SAVE`, `BGSAVE`, `LASTSAVE`
- Strings: `SET` with `NX`, `XX`, `EX`, `PX`, `EXAT`, `PXAT`, and `KEEPTTL`; `GET`, `GETSET`, `GETDEL`, `MGET`, `MSET`, `MSETNX`, `APPEND`, `STRLEN`, `GETRANGE`, `SETRANGE`, `INCR`, `DECR`, `INCRBY`, `DECRBY`, `INCRBYFLOAT`
- Expiration: `EXPIRE`, `PEXPIRE`, `EXPIREAT`, `PEXPIREAT`, `TTL`, `PTTL`, `PERSIST`
- Lists: `LPUSH`, `RPUSH`, `LPUSHX`, `RPUSHX`, `LPOP`, `RPOP`, `LLEN`, `LRANGE`, `LINDEX`, `LSET`, `LINSERT`, `LTRIM`, `LREM`
- Sets: `SADD`, `SREM`, `SMEMBERS`, `SISMEMBER`, `SMISMEMBER`, `SCARD`, `SPOP`, `SMOVE`, `SUNION`, `SINTER`, `SDIFF`, `SUNIONSTORE`, `SINTERSTORE`, `SDIFFSTORE`
- Hashes: `HSET`, `HMSET`, `HSETNX`, `HGET`, `HMGET`, `HDEL`, `HEXISTS`, `HLEN`, `HKEYS`, `HVALS`, `HGETALL`, `HINCRBY`, `HINCRBYFLOAT`, `HSTRLEN`
- Sorted sets: `ZADD` with `NX`, `XX`, and `CH`; `ZREM`, `ZSCORE`, `ZMSCORE`, `ZCARD`, `ZCOUNT`, `ZRANK`, `ZREVRANK`, `ZRANGE`, `ZREVRANGE`, `ZRANGEBYSCORE`, `ZREVRANGEBYSCORE`, `ZINCRBY`, `ZREMRANGEBYRANK`, `ZREMRANGEBYSCORE`
- Transactions and messaging: `WATCH`, `UNWATCH`, `MULTI`, `EXEC`, `DISCARD`, `SUBSCRIBE`, `UNSUBSCRIBE`, `PUBLISH`

## Compatibility limits

This is a broad educational clone, not a production Redis replacement. It does not implement Redis persistence formats, replication, clustering, Lua, ACL/authentication, blocking list commands, streams, HyperLogLog, geospatial commands, modules, full RESP3, or all Redis command options. `BGSAVE` writes a snapshot synchronously. Some string range behavior uses Java characters rather than Redis byte offsets for non-ASCII text. All commands share one lock, so this favors simple atomic behavior over throughput.
